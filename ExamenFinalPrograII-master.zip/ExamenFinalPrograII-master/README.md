# ExamenFinalPrograII
Resolución de la 3era serie del examen final

Marta Marina Bonilla Lémus
0907-21-1613

Aplicación utilizando Android Studio y kotlin que muestra 3 diferentes Textos con Animaciones.
Tiene una función para que al deslizar la pantalla cambie de texto, y en el último texto se encuentra un botón para ingresar a la pantalla Home

Link Clockifly
https://app.clockify.me/shared/654653df7553b60af75237e4

![image](https://github.com/Hinata1411/ExamenFinalPrograII/assets/85373964/baf42b3e-cd91-42f5-a7ff-adf8dfbebc6b)


![image](https://github.com/Hinata1411/ExamenFinalPrograII/assets/85373964/86842a05-ad5a-49c9-96ca-e97dea99d547)


![Captura de pantalla 2023-11-04 081123](https://github.com/Hinata1411/ExamenFinalPrograII/assets/85373964/f309331f-74c9-4ae7-9e04-5caf78fed46e)



![Captura de pantalla 2023-11-04 081401](https://github.com/Hinata1411/ExamenFinalPrograII/assets/85373964/f7f044eb-5d0d-46da-a87c-44acd99aa6d8)


![image](https://github.com/Hinata1411/ExamenFinalPrograII/assets/85373964/fbbb9f3f-0816-4f82-af6a-3b73dd6db409)


